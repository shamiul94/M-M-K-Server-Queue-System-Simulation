/**
 *
 * @author Khwilo
 */
public class Mm1_queue {    
    public static void main(String[] args) { 
	  Mm1_Modules mm1_modules = new Mm1_Modules();
          
          mm1_modules.simulate();
    }

   
}
